#include "utils/test.h"

#include "utils/scheduler.h"

#include "peripherals/adc.h"
#include "peripherals/dma.h"
#include "peripherals/gpio.h"
#include "peripherals/i2c.h"
#include "peripherals/spi.h"
#include "peripherals/tim.h"
#include "peripherals/usart.h"

#include "usbd_cdc_if.h"


void init_obj_pools() {
    TASK_POOL_init(ASYNC_BUZZER_play_note);

    TASK_POOL_init(ASYNC_BMI088_ReadSensorDMA);
    TASK_POOL_init(ASYNC_BMI088_Sensor_Publisher);

    TASK_POOL_init(ASYNC_W25Q_ReadStatusReg);
    TASK_POOL_init(ASYNC_W25Q_WriteEnable);
    TASK_POOL_init(ASYNC_W25Q_WaitForReady);
    TASK_POOL_init(ASYNC_W25Q_EraseSector);
    TASK_POOL_init(ASYNC_W25Q_EraseAll);
    TASK_POOL_init(ASYNC_W25Q_ReadData_Smol);
    TASK_POOL_init(ASYNC_W25Q_ReadData);
    TASK_POOL_init(ASYNC_W25Q_PageProgram);
    TASK_POOL_init(ASYNC_W25Q_WriteData);

    TASK_POOL_init(ASYNC_fs_read_write);

    TASK_POOL_init(ASYNC_update_usb_watchdog);
    TASK_POOL_init(ASYNC_test_usb);
    TASK_POOL_init(ASYNC_send_usb);
    TASK_POOL_init(ASYNC_update_IMU);
    TASK_POOL_init(ASYNC_test_w25q_page);
    TASK_POOL_init(ASYNC_test_w25q_write);
    TASK_POOL_init(ASYNC_test_fs);
    TASK_POOL_init(ASYNC_save_IMU);
    TASK_POOL_init(ASYNC_filtred_IMU);

    TASK_POOL_init(ASYNC_SPI_TxRx_DMA);

}

void init_components(COMPONENTS             *components,
                     BMI088                 *imu,
                     BMP388_HandleTypeDef   *bmp,
                     BUZZER                 *buzzer,
                    //  GPS_t                  *gps,
                     W25Q_Chip              *flash_chip,
                     RFM96_Chip             *lora_chip
) {
    components->imu = imu;
    components->bmp = bmp;
    components->buzzer = buzzer;
    // components->gps = gps;
    components->flash = flash_chip;
    components->lora = lora_chip;
}

void init_all_components(COMPONENTS* components) {
    BMI088_Init(components->imu, &hspi1,
        CS_ACC0_GPIO_Port, CS_ACC0_Pin,
        CS_GRYO_GPIO_Port, CS_GRYO_Pin);

    components->bmp->hi2c = &hi2c3;
    BMP388_Init(components->bmp);

    BUZZER_Init(components->buzzer, &htim3, TIM_CHANNEL_4);
    BUZZER_set_song_bank(&buzzer_song_bank);

    // GPS_Init(components->gps, &huart1);


    RFM96_Init(components->lora, &hspi1, CS_LORA_GPIO_Port, CS_LORA_Pin,
               RESET_LORA_GPIO_Port, RESET_LORA_Pin, 868000e3);

    W25Q_Init(components->flash, &hspi2, CS_FLASH_GPIO_Port, CS_FLASH_Pin, W25Q_Q_FULL_DEVICE_ID);


    // RFM96_Init(components->lora, &hspi1, N_CS_LORA_GPIO_Port, N_CS_LORA_Pin,
    //            N_RST_LORA_GPIO_Port, N_RST_LORA_Pin, 433365e3);
}


// ===========================================


MACHINE machine;


void init_machine(MACHINE* machine, COMPONENTS* components,
                  FLASH_STREAM* flash_stream
                //   DATAS* datas
) {
    machine->state = WAIT_USB;

    machine->components = components;
    init_all_components(components);

    machine->flash_stream = flash_stream;
    flash_stream_init(flash_stream, components->flash);

    // machine->datas = datas;
    // Datas_Init(datas, components->imu, components->bmp, components->gps);

    machine->usb_watchdog_bfr[0] = USBD_BUSY;
    machine->usb_watchdog_bfr[1] = USBD_BUSY;
    machine->usb_watchdog_bfr[2] = USBD_BUSY;

    machine->last_tick = 0;
    machine->last_time = HAL_GetTick();

    // ===== POST VOLE ===== POUR LIRE DIRECTEMENT ======
    // machine->state = WAIT_FOR_SENDING_DATA;
    // flash_stream->write_ptr = 0xffffff;
    // ===== POST VOLE ==================================
}



void add_task_if_flag(SCHEDULER* scheduler, MACHINE* machine) {
    switch (machine->state) {
    case WAIT_USB: {
        machine->state = DEFAULT_STATE;

        TASK *task_buz, *task_usb;

        task_buz = SCHEDULER_add_task_macro(scheduler, ASYNC_BUZZER_play_note, false);
        ASYNC_BUZZER_play_note_init(task_buz, machine->components->buzzer,
                             buzzer_song_bank.beep_0_freqs,
                             buzzer_song_bank.beep_0_durations, BUZZER_BEEP_SONG_SIZE);

        task_usb = SCHEDULER_add_task_macro(scheduler, ASYNC_update_usb_watchdog, false);
        ASYNC_update_usb_watchdog_init(task_usb, machine);

        break; }
    case USB_READY: {
        machine->state = TEST_SAVE_IMU;
        break; }

    case TEST_ASYNC: {
        machine->state = DEFAULT_STATE;

        TASK *task_buz, *task_usb;

        sprintf(machine->tx_buff, "IT'S WORKING, I CAN PRINT THINGS\n");

        task_buz = SCHEDULER_add_task_macro(scheduler, ASYNC_BUZZER_play_note, false);
        ASYNC_BUZZER_play_note_init(task_buz, machine->components->buzzer,
                             buzzer_song_bank.cccp_freqs,
                             buzzer_song_bank.cccp_durations,
                             BUZZER_CCCP_SONG_SIZE);

        task_usb = SCHEDULER_add_task_macro(scheduler, ASYNC_test_usb, false);
        ASYNC_test_usb_init(task_usb, machine->tx_buff, 26, 200);

        break; }
    case TEST_IMU: {
        machine->state = DEFAULT_STATE;

        TASK *task_buz, *task_imu, *task_usb;

        task_buz = SCHEDULER_add_task_macro(scheduler, ASYNC_BUZZER_play_note, false);
        ASYNC_BUZZER_play_note_init(task_buz, machine->components->buzzer,
                             buzzer_song_bank.beep_2_freqs,
                             buzzer_song_bank.beep_2_durations, BUZZER_BEEP_SONG_SIZE);

        task_imu = SCHEDULER_add_task_macro(scheduler, ASYNC_update_IMU, false);
        ASYNC_update_IMU_init(task_imu, 10);

        task_usb = SCHEDULER_add_task_macro(scheduler, ASYNC_send_usb, false);
        ASYNC_send_usb_init(task_usb, 10);
        break; }
    case TEST_W25Q_PAGE: {
        machine->state = DEFAULT_STATE;

        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_test_w25q_page, false);
        ASYNC_test_w25q_page_init(task);

        break; }
    case TEST_W25Q_WRITE: {
        machine->state = DEFAULT_STATE;

        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_test_w25q_write, false);
        ASYNC_test_w25q_write_init(task);

        break; }
    case TEST_FLASH_STREAM: {
        machine->state = DEFAULT_STATE;

        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_test_fs, false);
        ASYNC_test_fs_init(task, machine->flash_stream);

        break; }
    case TEST_SAVE_IMU: {
        machine->state = DEFAULT_STATE;

        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_save_IMU, false);
        ASYNC_save_IMU_init(task);

        break; }
    case TEST_FILTERED_IMU: {
        machine->state = DEFAULT_STATE;

        TASK* task = SCHEDULER_add_task_macro(scheduler, ASYNC_filtred_IMU, false);
        ASYNC_filtred_IMU_init(task);

        break; }
   
    default:
        break;
    }
}



void update_usb_watchdog(uint8_t *usb_watchdog_bfr) {
    usb_watchdog_bfr[0] = usb_watchdog_bfr[1];
    usb_watchdog_bfr[1] = usb_watchdog_bfr[2];
    usb_watchdog_bfr[2] = CDC_Transmit_FS(NULL, 0);
    HAL_Delay(1);
}

bool is_connected_to_usb(uint8_t *usb_watchdog_bfr) {
    return ((usb_watchdog_bfr[0] == USBD_OK) &&
            (usb_watchdog_bfr[1] == USBD_OK) &&
            (usb_watchdog_bfr[2] == USBD_OK));
}

TASK_POOL_CREATE(ASYNC_update_usb_watchdog);

void ASYNC_update_usb_watchdog_init(TASK *self, MACHINE *machine) {
    ASYNC_update_usb_watchdog_CONTEXT *context = (ASYNC_update_usb_watchdog_CONTEXT*)self->context;

    context->state = &(machine->state);
    context->usb_watchdog_bfr[0] = USBD_BUSY;
    context->usb_watchdog_bfr[1] = USBD_BUSY;
    context->usb_watchdog_bfr[2] = USBD_BUSY;
    context->next_time = 0;
}

TASK_RETURN ASYNC_update_usb_watchdog(SCHEDULER *scheduler, TASK *self) {
    ASYNC_update_usb_watchdog_CONTEXT *context = (ASYNC_update_usb_watchdog_CONTEXT*)self->context;

    UNUSED(scheduler);

    uint32_t current_time = HAL_GetTick();
    if (current_time >= context->next_time) {
        context->usb_watchdog_bfr[0] = context->usb_watchdog_bfr[1];
        context->usb_watchdog_bfr[1] = context->usb_watchdog_bfr[2];
        context->usb_watchdog_bfr[2] = CDC_Transmit_FS(NULL, 0);
        context->next_time = HAL_GetTick() + 1;

        if (is_connected_to_usb(context->usb_watchdog_bfr)) {
            *(context->state) = USB_READY;
            return TASK_RETURN_STOP;
        }
    }

    return TASK_RETURN_IDLE;
}



TASK_POOL_CREATE(ASYNC_test_usb);

void ASYNC_test_usb_init(TASK *self, char *buff, int len, uint32_t delay) {
    ASYNC_test_usb_CONTEXT *context = (ASYNC_test_usb_CONTEXT*)self->context;

    context->buff = buff;
    context->len = len;
    context->index = -1;
    context->next_time = 0;
    context->delay = delay;
}

TASK_RETURN ASYNC_test_usb(SCHEDULER *scheduler, TASK *self) {
    ASYNC_test_usb_CONTEXT *context = (ASYNC_test_usb_CONTEXT*)self->context;
    UNUSED(scheduler);

    uint32_t current_tick = HAL_GetTick();
    if (context->index == -1) {
        HAL_Delay(1);
        CDC_Transmit_FS((uint8_t*)"START \"", 8);
        context->next_time = current_tick + context->delay;
        context->index = 0;
    } else if (context->index < context->len) {
        if (current_tick >= context->next_time) {
            char* c = context->buff + context->index;
            CDC_Transmit_FS((uint8_t*)c, 1);
            context->index++;
            context->next_time = current_tick + context->delay;
        }
    } else {
        HAL_Delay(1);
        CDC_Transmit_FS((uint8_t*)"\" END\n", 7);
        return TASK_RETURN_STOP;
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_send_usb);

void ASYNC_send_usb_init(TASK *self, uint32_t delay) {
    ASYNC_send_usb_CONTEXT *context = (ASYNC_send_usb_CONTEXT*)self->context;

    context->next_time = 0;
    context->delay = delay;
}

TASK_RETURN ASYNC_send_usb(SCHEDULER *scheduler, TASK *self) {
    ASYNC_send_usb_CONTEXT *context = (ASYNC_send_usb_CONTEXT*)self->context;

    UNUSED(scheduler);

    uint32_t current_tick = HAL_GetTick();

    if (current_tick >= context->next_time) {
        char buff[256];
        char acc_x[10], acc_y[10], acc_z[10];
        char gyr_x[10], gyr_y[10], gyr_z[10];
        char time[10];
        // int num_calls = machine.components->imu->num_calls;

        float_format(acc_x, machine.components->imu->acc_mps2[0], 5, 10);
        float_format(acc_y, machine.components->imu->acc_mps2[1], 5, 10);
        float_format(acc_z, machine.components->imu->acc_mps2[2], 5, 10);

        float_format(gyr_x, machine.components->imu->gyr_rps[0], 5, 10);
        float_format(gyr_y, machine.components->imu->gyr_rps[1], 5, 10);
        float_format(gyr_z, machine.components->imu->gyr_rps[2], 5, 10);

        float_format(time, (float)current_tick, 1, 10);

        sprintf(buff, "%s, %s, %s, %s, %s, %s, %s\n", time, acc_x, acc_y, acc_z,
                                                            gyr_x, gyr_y, gyr_z);
        // sprintf(buff, "%s, %s, %s\r\n", acc_x, acc_y, acc_z);
        // sprintf(buff, "%s, %s, %s\r\n", gyr_x, gyr_y, gyr_z);
        CDC_Transmit_FS((uint8_t*)buff, strlen(buff));

        context->next_time = current_tick + context->delay;
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_update_IMU);

void ASYNC_update_IMU_init(TASK *self, uint32_t delay) {
    ASYNC_update_IMU_CONTEXT *context = (ASYNC_update_IMU_CONTEXT*)self->context;

    context->continue_update = true;
    context->next_time = 0;
    context->delay = delay;
}

TASK_RETURN ASYNC_update_IMU(SCHEDULER *scheduler, TASK *self) {
    ASYNC_update_IMU_CONTEXT *context = (ASYNC_update_IMU_CONTEXT*)self->context;

    uint32_t current_tick = HAL_GetTick();
    if (context->continue_update) {
        if (current_tick >= context->next_time) {

            TASK *task_acc, *task_gyr;

            task_acc = SCHEDULER_add_task(scheduler, ASYNC_BMI088_ReadAccelerometerDMA,
                true, (OBJ_POOL*)ASYNC_BMI088_ReadSensorDMA_POOL);
            ASYNC_BMI088_ReadSensorDMA_init(task_acc, machine.components->imu);

            task_gyr = SCHEDULER_add_task(scheduler, ASYNC_BMI088_ReadGyroscopeDMA,
                true, (OBJ_POOL*)ASYNC_BMI088_ReadSensorDMA_POOL);
            ASYNC_BMI088_ReadSensorDMA_init(task_gyr, machine.components->imu);

            context->next_time = current_tick + context->delay;
        }
    } else {
        return TASK_RETURN_STOP;
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_test_w25q_page);

void ASYNC_test_w25q_page_init(TASK *self) {
    ASYNC_test_w25q_page_CONTEXT *context = (ASYNC_test_w25q_page_CONTEXT*)self->context;

    context->flash_chip = machine.components->flash;

    context->tx_buf = GMS_alloc(&GMS_memory, ASYNC_test_w25q_page_SIZE);
    context->rx_buf = GMS_alloc(&GMS_memory, ASYNC_test_w25q_page_SIZE + ASYNC_test_w25q_page_ADDR);

    uint8_t tx_buf[ASYNC_test_w25q_page_SIZE];

    for (size_t i = 0; i < ASYNC_test_w25q_page_SIZE; i++) {
        // tx_buf[i] = i;
        tx_buf[i] = ASYNC_test_w25q_page_SIZE - i;
    }
    memcpy(context->tx_buf, tx_buf, ASYNC_test_w25q_page_SIZE);
    memset(context->rx_buf, 0, ASYNC_test_w25q_page_SIZE + ASYNC_test_w25q_page_ADDR);

    context->state = ASYNC_test_w25q_page_START;
}

TASK_RETURN ASYNC_test_w25q_page(SCHEDULER *scheduler, TASK *self) {
    ASYNC_test_w25q_page_CONTEXT *context = (ASYNC_test_w25q_page_CONTEXT*)self->context;
    UNUSED(scheduler);

    switch (context->state) {
    case ASYNC_test_w25q_page_START: {
        context->is_done = false;
        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_EraseSector, false);
        ASYNC_W25Q_EraseSector_init(task, context->flash_chip, 0);
        task->is_done = &(context->is_done);
        context->state = ASYNC_test_w25q_page_WAIT_ERASE;
        break; }
    case ASYNC_test_w25q_page_WAIT_ERASE: {
        if (context->is_done) {
            context->is_done = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_PageProgram, false);
            ASYNC_W25Q_PageProgram_init(task, context->flash_chip, context->tx_buf, ASYNC_test_w25q_page_SIZE, ASYNC_test_w25q_page_ADDR);
            task->is_done = &(context->is_done);
            context->state = ASYNC_test_w25q_page_WAIT_TX;
        }
        break; }
    case ASYNC_test_w25q_page_WAIT_TX: {
        if (context->is_done) {
            context->is_done = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_ReadData, false);
            ASYNC_W25Q_ReadData_init(task, context->flash_chip, context->rx_buf, ASYNC_test_w25q_page_ADDR + ASYNC_test_w25q_page_SIZE, 0);
            task->is_done = &(context->is_done);
            context->state = ASYNC_test_w25q_page_WAIT_RX;
        }
        break; }
    case ASYNC_test_w25q_page_WAIT_RX: {
        if (context->is_done) {
            for (size_t i = 0; i < ASYNC_test_w25q_page_SIZE; i++) {
                if (context->tx_buf[i] != context->rx_buf[i + ASYNC_test_w25q_page_ADDR]) {
                    break;
                }
            }

            GMS_free(&GMS_memory, context->tx_buf);
            GMS_free(&GMS_memory, context->rx_buf);
            return TASK_RETURN_STOP;
        }
        break; }
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_test_w25q_write);

void ASYNC_test_w25q_write_init(TASK *self) {
    ASYNC_test_w25q_write_CONTEXT *context = (ASYNC_test_w25q_write_CONTEXT*)self->context;

    context->flash_chip = machine.components->flash;

    uint8_t tx_buf[ASYNC_test_w25q_write_SIZE];

    for (size_t i = 0; i < ASYNC_test_w25q_write_SIZE; i++) {
        tx_buf[i] = i;
    }
    
    context->tx_buf = GMS_alloc(&GMS_memory, ASYNC_test_w25q_write_SIZE);
    context->rx_buf = GMS_alloc(&GMS_memory, ASYNC_test_w25q_write_SIZE + ASYNC_test_w25q_write_ADDR);

    memcpy(context->tx_buf, tx_buf, ASYNC_test_w25q_write_SIZE);
    memset(context->rx_buf, 0, ASYNC_test_w25q_write_SIZE + ASYNC_test_w25q_write_ADDR);

    context->state = ASYNC_test_w25q_write_START;
}

TASK_RETURN ASYNC_test_w25q_write(SCHEDULER *scheduler, TASK *self) {
    ASYNC_test_w25q_write_CONTEXT *context = (ASYNC_test_w25q_write_CONTEXT*)self->context;
    UNUSED(scheduler);

    switch (context->state) {
    case ASYNC_test_w25q_write_START: {
        context->is_done = false;
        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_EraseSector, false);
        ASYNC_W25Q_EraseSector_init(task, context->flash_chip, 0);
        task->is_done = &(context->is_done);
        context->state = ASYNC_test_w25q_write_WAIT_ERASE;
        break; }
    case ASYNC_test_w25q_write_WAIT_ERASE: {
        if (context->is_done) {
            context->is_done = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_WriteData, false);
            ASYNC_W25Q_WriteData_init(task, context->flash_chip, context->tx_buf, ASYNC_test_w25q_write_SIZE, ASYNC_test_w25q_write_ADDR);
            task->is_done = &(context->is_done);
            context->state = ASYNC_test_w25q_write_WAIT_TX;
        }
        break; }
    case ASYNC_test_w25q_write_WAIT_TX: {
        if (context->is_done) {
            context->is_done = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_ReadData, false);
            ASYNC_W25Q_ReadData_init(task, context->flash_chip, context->rx_buf, ASYNC_test_w25q_write_SIZE + ASYNC_test_w25q_write_ADDR, 0);
            task->is_done = &(context->is_done);
            context->state = ASYNC_test_w25q_write_WAIT_RX;
        }
        break; }
    case ASYNC_test_w25q_write_WAIT_RX: {
        if (context->is_done) {
            for (size_t i = 0; i < ASYNC_test_w25q_write_SIZE; i++) {
                if (context->tx_buf[i] != context->rx_buf[i + ASYNC_test_w25q_write_ADDR]) {
                    break;
                }
            }

            GMS_free(&GMS_memory, context->tx_buf);
            GMS_free(&GMS_memory, context->rx_buf);
            return TASK_RETURN_STOP;
        }
        break; }
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_test_fs);

void ASYNC_test_fs_init(TASK *self, FLASH_STREAM *flash_stream) {
    ASYNC_test_fs_CONTEXT *context = (ASYNC_test_fs_CONTEXT*)self->context;

    context->flash_stream = flash_stream;

    float tx[ASYNC_test_fs_float_SIZE];

    for (int i = 0; i < ASYNC_test_fs_packet_SIZE; i++) {
        tx[i + 0] = 31.4 + 1/((float)i + 2.0);
        tx[i + 4] = 69.0 + 1/((float)i + 2.0);
        tx[i + 8] = 42.0 + 1/((float)i + 2.0);
        // ASYNC_test_fs_nb_packet == 3
    }

    context->tx_buf = GMS_alloc(&GMS_memory, ASYNC_test_fs_uint8_SIZE);
    context->rx_buf = GMS_alloc(&GMS_memory, ASYNC_test_fs_uint8_SIZE);

    memcpy(context->tx_buf, tx, ASYNC_test_fs_uint8_SIZE);

    context->idx = 0;
    context->state = ASYNC_test_fs_START;
}

TASK_RETURN ASYNC_test_fs(SCHEDULER *scheduler, TASK *self) {
    ASYNC_test_fs_CONTEXT *context = (ASYNC_test_fs_CONTEXT*)self->context;

    switch (context->state) {
    case ASYNC_test_fs_START: {
        context->is_done = false;
        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_EraseSector, false);
        ASYNC_W25Q_EraseSector_init(task, context->flash_stream->flash_chip, 0);
        task->is_done = &(context->is_done);
        context->state = ASYNC_test_fs_WAIT_ERASE;
        break; }
    case ASYNC_test_fs_WAIT_ERASE: {
        if (context->is_done) {
            context->state = ASYNC_test_fs_START_TX;
        }
        break; }
    case ASYNC_test_fs_START_TX: {
        context->is_done = false;

        uint8_t *tx = context->tx_buf + context->idx * ASYNC_test_fs_packet_SIZE * sizeof(float);

        TASK *task = SCHEDULER_add_task(scheduler, ASYNC_fs_write, false, (OBJ_POOL*)ASYNC_fs_read_write_POOL);
        ASYNC_fs_read_write_init(task, context->flash_stream, tx, ASYNC_test_fs_packet_SIZE * sizeof(float));

        task->is_done = &(context->is_done);
        context->state = ASYNC_test_fs_WAIT_TX;
        break; }
    case ASYNC_test_fs_WAIT_TX: {
        if (context->is_done) {
            if (context->idx < ASYNC_test_fs_nb_packet) {
                context->idx += 1;
                context->state = ASYNC_test_fs_START_TX;
            } else {
                context->idx = 0;
                context->state = ASYNC_test_fs_START_RX;
            }
        }
        break; }
    case ASYNC_test_fs_START_RX: {
        context->is_done = false;

        uint8_t *rx = context->rx_buf + context->idx * ASYNC_test_fs_packet_SIZE * sizeof(float);

        TASK *task = SCHEDULER_add_task(scheduler, ASYNC_fs_read, false, (OBJ_POOL*)ASYNC_fs_read_write_POOL);
        ASYNC_fs_read_write_init(task, context->flash_stream, rx, ASYNC_test_fs_packet_SIZE * sizeof(float));
        
        task->is_done = &(context->is_done);
        context->state = ASYNC_test_fs_WAIT_RX;
        break; }
    case ASYNC_test_fs_WAIT_RX: {
        if (context->is_done) {
            if (context->idx < ASYNC_test_fs_nb_packet) {
                context->idx += 1;
                context->state = ASYNC_test_fs_START_RX;
            } else {
                context->state = ASYNC_test_fs_DONE_RX;
            }
        }
        break; }
    case ASYNC_test_fs_DONE_RX: {

        for (size_t i = 0; i < ASYNC_test_fs_uint8_SIZE; i++) {
            if (context->tx_buf[i] != context->rx_buf[i]) {
                break;
            }
        }

        GMS_free(&GMS_memory, context->tx_buf);
        GMS_free(&GMS_memory, context->rx_buf);
        return TASK_RETURN_STOP;
        break; }
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_save_IMU);

void ASYNC_save_IMU_init(TASK *self) {
    ASYNC_save_IMU_CONTEXT *context = (ASYNC_save_IMU_CONTEXT*)self->context;

    context->max_delay = 30000;  // 30 seconds
    context->imu_delay = 10;     // 10 ms
    context->state = ASYNC_save_IMU_START_ERASE;

    context->ready = false;
    context->save_done = false;
}

TASK_RETURN ASYNC_save_IMU(SCHEDULER* scheduler, TASK* self) {
    ASYNC_save_IMU_CONTEXT *context = (ASYNC_save_IMU_CONTEXT*)self->context;

    uint32_t current_tick = HAL_GetTick();

    switch (context->state) {
    case ASYNC_save_IMU_START_ERASE: {
        context->ready = false;
        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_EraseAll, false);
        ASYNC_W25Q_EraseAll_init(task, machine.flash_stream->flash_chip);
        task->is_done = &(context->ready);
        context->state = ASYNC_save_IMU_START_WAITING;
        break; }
    case ASYNC_save_IMU_START_WAITING: {
        if (context->ready) {
            context->ready = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_WaitForReady, false);
            ASYNC_W25Q_WaitForReady_init(task, machine.flash_stream->flash_chip);
            task->is_done = &(context->ready); 
            context->state = ASYNC_save_IMU_WAIT_READY;
        }
        break; }
    case ASYNC_save_IMU_WAIT_READY: {
        if (context->ready) {
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_BUZZER_play_note, false);
            ASYNC_BUZZER_play_note_init(task, machine.components->buzzer,
                                 buzzer_song_bank.beep_1_freqs,
                                 buzzer_song_bank.beep_1_durations,
                                 BUZZER_BEEP_SONG_SIZE);
            
            CDC_Transmit_FS((uint8_t*)"accel_x,accel_y,accel_z,gyro_x,gyro_y,gyro_z,time\n", 50);
            
            context->state = ASYNC_save_IMU_START_UPDATE;
        }
        break; }
    case ASYNC_save_IMU_START_UPDATE: {
        context->first_time = current_tick;
        context->task_imu = SCHEDULER_add_task_macro(scheduler, ASYNC_update_IMU, true);
        ASYNC_update_IMU_init(context->task_imu, context->imu_delay);

        context->state = ASYNC_save_IMU_WAIT_UPDATE;
        break; }
    case ASYNC_save_IMU_WAIT_UPDATE: {
        if (machine.components->imu->new_acc_data && machine.components->imu->new_gyr_data) {
            machine.components->imu->new_acc_data = false;
            machine.components->imu->new_gyr_data = false;

            context->save_done = false;

            context->datas_buff[0] = machine.components->imu->acc_mps2[0];
            context->datas_buff[1] = machine.components->imu->acc_mps2[1];
            context->datas_buff[2] = machine.components->imu->acc_mps2[2];
            context->datas_buff[3] = machine.components->imu->gyr_rps[0];
            context->datas_buff[4] = machine.components->imu->gyr_rps[1];
            context->datas_buff[5] = machine.components->imu->gyr_rps[2];
            context->datas_buff[6] = (float)current_tick;

            TASK *task = SCHEDULER_add_task(scheduler, ASYNC_fs_write, false, (OBJ_POOL*)ASYNC_fs_read_write_POOL);
            ASYNC_fs_read_write_init(task, machine.flash_stream, (uint8_t*)(context->datas_buff), ASYNC_save_IMU_DATA_NUMBER * sizeof(float));
            task->is_done = &(context->save_done);

            context->state = ASYNC_save_IMU_WAIT_SAVE;
        }
        break; }
    case ASYNC_save_IMU_WAIT_SAVE: {
        if (context->save_done) {
            if (current_tick - context->first_time >= context->max_delay) {
                context->state = ASYNC_save_IMU_END_UPDATE;
            } else {
                context->state = ASYNC_save_IMU_WAIT_UPDATE;
            }
        }
        break; }
    case ASYNC_save_IMU_END_UPDATE: {
        ((ASYNC_update_IMU_CONTEXT*)(context->task_imu->context))->continue_update = false;

        context->state = ASYNC_save_IMU_START_LOAD;

        TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_BUZZER_play_note, false);
        ASYNC_BUZZER_play_note_init(task, machine.components->buzzer,
                             buzzer_song_bank.beep_2_freqs,
                             buzzer_song_bank.beep_2_durations,
                             BUZZER_BEEP_SONG_SIZE);
        break; }
    case ASYNC_save_IMU_START_LOAD: {
        context->save_done = false;

        TASK *task = SCHEDULER_add_task(scheduler, ASYNC_fs_read, false, (OBJ_POOL*)ASYNC_fs_read_write_POOL);
        ASYNC_fs_read_write_init(task, machine.flash_stream, (uint8_t*)(context->datas_buff), ASYNC_save_IMU_DATA_NUMBER * sizeof(float));
        task->is_done = &(context->save_done);

        context->state = ASYNC_save_IMU_WAIT_LOAD;
        break; }
    case ASYNC_save_IMU_WAIT_LOAD: {
        if (context->save_done) {
            context->state = ASYNC_save_IMU_START_SEND;
        }
        break; }
    case ASYNC_save_IMU_START_SEND: {
        context->next_time = current_tick + 2;
        char buff[256];
        char acc_x[10], acc_y[10], acc_z[10];
        char gyr_x[10], gyr_y[10], gyr_z[10];
        char time[10];

        float_format(acc_x, context->datas_buff[0], 5, 10);
        float_format(acc_y, context->datas_buff[1], 5, 10);
        float_format(acc_z, context->datas_buff[2], 5, 10);

        float_format(gyr_x, context->datas_buff[3], 5, 10);
        float_format(gyr_y, context->datas_buff[4], 5, 10);
        float_format(gyr_z, context->datas_buff[5], 5, 10);

        float_format(time, context->datas_buff[6], 1, 10);

        sprintf(buff, "%s, %s, %s, %s, %s, %s, %s\r\n", acc_x, acc_y, acc_z,
                                                        gyr_x, gyr_y, gyr_z, time);
        CDC_Transmit_FS((uint8_t*)buff, strlen(buff));

        context->state = ASYNC_save_IMU_WAIT_SEND;
        break; }
    case ASYNC_save_IMU_WAIT_SEND: {
        if (current_tick >= context->next_time) {
            if (machine.flash_stream->read_ptr < machine.flash_stream->write_ptr) {
                context->state =  ASYNC_save_IMU_START_LOAD;
            } else {
                context->state = ASYNC_save_IMU_END_SEND;
            }
        }
        break; }
    case ASYNC_save_IMU_END_SEND: {
        return TASK_RETURN_STOP;
        break; }
    }
    return TASK_RETURN_IDLE;
}


TASK_POOL_CREATE(ASYNC_filtred_IMU);

void ASYNC_filtred_IMU_init(TASK *self) {
    ASYNC_filtred_IMU_CONTEXT *context = (ASYNC_filtred_IMU_CONTEXT*)self->context;

    context->acc_offset_num = 0;
    context->gyr_offset_num = 0;

    context->acc_offset_mean[0] = 0;
    context->acc_offset_mean[1] = 0;
    context->acc_offset_mean[2] = 0;

    context->gyr_offset_mean[0] = 0;
    context->gyr_offset_mean[1] = 0;
    context->gyr_offset_mean[2] = 0;

    context->state = ASYNC_filtred_IMU_START;    
}

TASK_RETURN ASYNC_filtred_IMU(SCHEDULER *scheduler, TASK *self) {
    ASYNC_filtred_IMU_CONTEXT *context = (ASYNC_filtred_IMU_CONTEXT*)self->context;

    uint32_t current_tick = HAL_GetTick();

    switch (context->state) {
    case ASYNC_filtred_IMU_START: {
        context->w25q_ready = false;
        TASK *task;
        task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_EraseAll, false);
        ASYNC_W25Q_EraseAll_init(task, machine.flash_stream->flash_chip);
        task->is_done = &(context->w25q_ready);

        task = SCHEDULER_add_task(scheduler, ASYNC_BMI088_Accelero_Publisher, true, (OBJ_POOL*)ASYNC_BMI088_Sensor_Publisher_POOL);
        ASYNC_BMI088_Sensor_Publisher_init(task, machine.components->imu, &(context->acc_data), 10);

        task = SCHEDULER_add_task(scheduler, ASYNC_BMI088_Gyro_Publisher, true, (OBJ_POOL*)ASYNC_BMI088_Sensor_Publisher_POOL);
        ASYNC_BMI088_Sensor_Publisher_init(task, machine.components->imu, &(context->gyr_data), 10);

        context->state = ASYNC_filtred_IMU_START_WAITING_W25Q;
        break; }
    case ASYNC_filtred_IMU_START_WAITING_W25Q: {
        if (context->w25q_ready) {
            context->w25q_ready = false;
            TASK *task = SCHEDULER_add_task_macro(scheduler, ASYNC_W25Q_WaitForReady, false);
            ASYNC_W25Q_WaitForReady_init(task, machine.flash_stream->flash_chip);
            task->is_done = &(context->w25q_ready);
            context->state = ASYNC_filtred_IMU_WAIT_OFFSET_BMI_AND_W25Q;
        }
        break; }
    case ASYNC_filtred_IMU_WAIT_OFFSET_BMI_AND_W25Q: {
        if (!context->w25q_ready || context->acc_offset_num < 100 || context->gyr_offset_num < 100) {
            BMI088_Data data;
            if (context->acc_offset_num < 100) {
                size_t new_acc_num = context->acc_data.new_data_num;
                for (size_t i = 0; i < new_acc_num; i++) {
                    BMI088_Data_Pub_pop(&(context->acc_data), &data);
                    context->acc_offset[0][context->acc_offset_num + i] = data.x;
                    context->acc_offset[1][context->acc_offset_num + i] = data.y;
                    context->acc_offset[2][context->acc_offset_num + i] = data.z;
                }
                context->acc_offset_num += new_acc_num;
            }
            if (context->gyr_offset_num < 100) {
                size_t new_gyr_num = context->gyr_data.new_data_num;
                for (size_t i = 0; i < new_gyr_num; i++) {
                    BMI088_Data_Pub_pop(&(context->gyr_data), &data);
                    context->gyr_offset[0][context->gyr_offset_num + i] = data.x;
                    context->gyr_offset[1][context->gyr_offset_num + i] = data.y;
                    context->gyr_offset[2][context->gyr_offset_num + i] = data.z;
                }
                context->gyr_offset_num += new_gyr_num;
            }
        } else {
            context->state = ASYNC_filtred_IMU_OFFSET_CALCULUS;
        }
        break; }
    case ASYNC_filtred_IMU_OFFSET_CALCULUS: {

        for (size_t i = 0; i < context->acc_offset_num; i++) {
            context->acc_offset_mean[0] += context->acc_offset[0][i];
            context->acc_offset_mean[1] += context->acc_offset[1][i];
            context->acc_offset_mean[2] += context->acc_offset[2][i];

            context->gyr_offset_mean[0] += context->gyr_offset[0][i];
            context->gyr_offset_mean[1] += context->gyr_offset[1][i];
            context->gyr_offset_mean[2] += context->gyr_offset[2][i];
        }

        context->acc_offset_mean[0] /= context->acc_offset_num;
        context->acc_offset_mean[1] /= context->acc_offset_num;
        context->acc_offset_mean[2] /= context->acc_offset_num;

        context->gyr_offset_mean[0] /= context->gyr_offset_num;
        context->gyr_offset_mean[1] /= context->gyr_offset_num;
        context->gyr_offset_mean[2] /= context->gyr_offset_num;

        char acc_x[10], acc_y[10], acc_z[10];
        char gyr_x[10], gyr_y[10], gyr_z[10];

        float_format(acc_x, context->acc_offset_mean[0], 5, 10);
        float_format(acc_y, context->acc_offset_mean[1], 5, 10);
        float_format(acc_z, context->acc_offset_mean[2], 5, 10);
        
        float_format(gyr_x, context->gyr_offset_mean[0], 5, 10);
        float_format(gyr_y, context->gyr_offset_mean[1], 5, 10);
        float_format(gyr_z, context->gyr_offset_mean[2], 5, 10);

        char buff[256];

        sprintf(buff, "acc_offset: %s, %s, %s\ngyr_offset: %s, %s, %s\n",
                acc_x, acc_y, acc_z, gyr_x, gyr_y, gyr_z);
        CDC_Transmit_FS((uint8_t*)buff, strlen(buff));

        return TASK_RETURN_STOP;
        break; }
    }
    return TASK_RETURN_IDLE;
}
