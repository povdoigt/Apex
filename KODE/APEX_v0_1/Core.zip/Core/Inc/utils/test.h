#ifndef TEST_H
#define TEST_H

#include "stm32f4xx_hal.h"

#include "drivers/BMI088.h"
#include "drivers/BMP388.h"
#include "drivers/buzzer.h"
#include "drivers/gps.h"
#include "drivers/led.h"
#include "drivers/rfm96w.h"
#include "drivers/w25q_mem.h"

#include "utils/flash_stream.h"



typedef struct COMPONENTS {
    BMI088                  *imu;
    BMP388_HandleTypeDef    *bmp;
    BUZZER                  *buzzer;
    GPS_t                   *gps;
    W25Q_Chip               *flash;
    RFM96_Chip              *lora;
} COMPONENTS;

typedef struct DATAS {
    // Sensors
    BMI088                  *imu;
    BMP388_HandleTypeDef    *bmp;
    GPS_t                   *gps;

    // Datas
    float accel[3];     // [m/s^2]
    float gyro[3];      // [rad/s]
    // float mag[3];       // ???
    float temp;         // [C]
    float pressure;     // [Pa]
    float longitude;    // [deg]
    float latitude;     // [deg]
    float time;         // [ms]
} DATAS;



typedef enum MACHINE_STATE {
    // ANALYSING_INFO,

    // WAIT_FOR_GPS_FIX,

    // SEND_GONOGO,
    // WAIT_RECIEVE_GONOGO,
    // RECIEVE_GONOGO,

    // BEGIN_FLASH_ERASING,
    // FLASH_ERASING,
    // END_FLASH_ERASING,

    // GETTING_DATA,

    // WAIT_FOR_SENDING_DATA, // <-- mode pour attendre et lire directement les données
    // BEGIN_SENDING_DATA,
    // SENDING_DATA,
    // END_SENDING_DATA,

    START,
    WAIT_USB,
    USB_READY,
    TEST_ASYNC,
    TEST_IMU,
    TEST_W25Q_PAGE,
    TEST_W25Q_WRITE,
    TEST_FLASH_STREAM,
    TEST_SAVE_IMU,
    TEST_FILTERED_IMU,

    // IS_STOPPED,
    // STOP,

    DEFAULT_STATE = 0xff
} MACHINE_STATE;

typedef struct MACHINE {
    MACHINE_STATE  state;

    COMPONENTS* components;
    FLASH_STREAM* flash_stream;
    DATAS* datas;

    char           tx_buff[256];
    uint8_t        usb_watchdog_bfr[3];

    uint32_t       last_time;
    uint32_t       last_tick;
} MACHINE;

extern MACHINE machine;

void init_obj_pools(void);

void init_components(COMPONENTS             *components,
                     BMI088                 *imu,
                     BMP388_HandleTypeDef   *bmp,
                     BUZZER                 *buzzer,
                    //  GPS_t                  *gps,
                     W25Q_Chip              *flash_chip,
                     RFM96_Chip             *lora_chip
);

void init_all_components(COMPONENTS *components);

void init_machine(MACHINE *machine, COMPONENTS *components,
                  FLASH_STREAM *flash_stream
                //   DATAS *datas
);

void add_task_if_flag(SCHEDULER *scheduler, MACHINE *machine);

void update_usb_watchdog(uint8_t *usb_watchdog_bfr);
bool is_connected_to_usb(uint8_t *usb_watchdog_bfr);

#define ASYNC_update_usb_watchdog_NUMBER 2

typedef struct ASYNC_update_usb_watchdog_CONTEXT {
    MACHINE_STATE* state;
    uint8_t usb_watchdog_bfr[3];
    uint32_t next_time;
} ASYNC_update_usb_watchdog_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_update_usb_watchdog);

void ASYNC_update_usb_watchdog_init(TASK *self, MACHINE *machine);
TASK_RETURN ASYNC_update_usb_watchdog(SCHEDULER *scheduler, TASK *self);



#define ASYNC_test_usb_NUMBER 5

typedef struct ASYNC_test_usb_CONTEXT {
    char* buff;
    int len;
    int index;
    uint32_t delay;
    uint32_t next_time;
} ASYNC_test_usb_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_test_usb);

void ASYNC_test_usb_init(TASK *self, char *buff, int len, uint32_t delay);
TASK_RETURN ASYNC_test_usb(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_send_usb_NUMBER 5

typedef struct ASYNC_send_usb_CONTEXT {
    uint32_t delay;
    uint32_t next_time;
} ASYNC_send_usb_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_send_usb);

void ASYNC_send_usb_init(TASK *self, uint32_t delay);
TASK_RETURN ASYNC_send_usb(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_update_IMU_NUMBER 5

typedef struct ASYNC_update_IMU_CONTEXT {
    bool      continue_update;
    uint32_t  delay;
    uint32_t  next_time;
} ASYNC_update_IMU_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_update_IMU);

void ASYNC_update_IMU_init(TASK *self, uint32_t delay);
TASK_RETURN ASYNC_update_IMU(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_test_w25q_page_NUMBER 5

#define ASYNC_test_w25q_page_SIZE 24
#define ASYNC_test_w25q_page_ADDR 245
// #define ASYNC_test_w25q_page_ADDR 10

typedef enum ASYNC_test_w25q_page_STATE {
    ASYNC_test_w25q_page_START,
    ASYNC_test_w25q_page_WAIT_ERASE,
    ASYNC_test_w25q_page_WAIT_TX,
    ASYNC_test_w25q_page_WAIT_RX
} ASYNC_test_w25q_page_STATE;

typedef struct ASYNC_test_w25q_page_CONTEXT {
    W25Q_Chip* flash_chip;

    uint8_t *tx_buf;
    uint8_t *rx_buf;

    bool is_done;

    ASYNC_test_w25q_page_STATE state;
} ASYNC_test_w25q_page_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_test_w25q_page);

void ASYNC_test_w25q_page_init(TASK *self);
TASK_RETURN ASYNC_test_w25q_page(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_test_w25q_write_NUMBER 5

#define ASYNC_test_w25q_write_SIZE 0x300
#define ASYNC_test_w25q_write_ADDR 0x30
// #define ASYNC_test_w25q_write_SIZE 10 * sizeof(float)
// #define ASYNC_test_w25q_write_ADDR 3 * sizeof(float)

typedef enum ASYNC_test_w25q_write_STATE {
    ASYNC_test_w25q_write_START,
    ASYNC_test_w25q_write_WAIT_ERASE,
    ASYNC_test_w25q_write_WAIT_TX,
    ASYNC_test_w25q_write_WAIT_RX
} ASYNC_test_w25q_write_STATE;

typedef struct ASYNC_test_w25q_write_CONTEXT {
    W25Q_Chip* flash_chip;

    uint8_t *tx_buf;
    uint8_t *rx_buf;

    bool is_done;

    ASYNC_test_w25q_write_STATE state;
} ASYNC_test_w25q_write_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_test_w25q_write);

void ASYNC_test_w25q_write_init(TASK *self);
TASK_RETURN ASYNC_test_w25q_write(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_test_fs_NUMBER 5

#define ASYNC_test_fs_packet_SIZE 7
#define ASYNC_test_fs_nb_packet 3
#define ASYNC_test_fs_float_SIZE ASYNC_test_fs_packet_SIZE * ASYNC_test_fs_nb_packet
#define ASYNC_test_fs_uint8_SIZE ASYNC_test_fs_float_SIZE * sizeof(float)

typedef enum ASYNC_test_fs_STATE {
    ASYNC_test_fs_START,
    ASYNC_test_fs_WAIT_ERASE,
    ASYNC_test_fs_START_TX,
    ASYNC_test_fs_WAIT_TX,
    ASYNC_test_fs_START_RX,
    ASYNC_test_fs_WAIT_RX,
    ASYNC_test_fs_DONE_RX
} ASYNC_test_fs_STATE;

typedef struct ASYNC_test_fs_CONTEXT {
    FLASH_STREAM* flash_stream;

    uint8_t *tx_buf;
    uint8_t *rx_buf;
    
    bool is_done;

    uint8_t idx;
    ASYNC_test_fs_STATE state;
} ASYNC_test_fs_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_test_fs);

void ASYNC_test_fs_init(TASK *self, FLASH_STREAM *flash_stream);
TASK_RETURN ASYNC_test_fs(SCHEDULER *scheduler, TASK *self);

// =============================================

#define ASYNC_save_IMU_NUMBER 5

#define ASYNC_save_IMU_DATA_NUMBER 7

typedef enum ASYNC_save_IMU_STATE {
    ASYNC_save_IMU_START_ERASE,
    ASYNC_save_IMU_START_WAITING,
    ASYNC_save_IMU_WAIT_READY,
    ASYNC_save_IMU_START_UPDATE,
    ASYNC_save_IMU_WAIT_UPDATE,
    ASYNC_save_IMU_WAIT_SAVE,
    ASYNC_save_IMU_END_UPDATE,
    ASYNC_save_IMU_START_LOAD,
    ASYNC_save_IMU_WAIT_LOAD,
    ASYNC_save_IMU_START_SEND,
    ASYNC_save_IMU_WAIT_SEND,
    ASYNC_save_IMU_END_SEND,
} ASYNC_save_IMU_STATE;

typedef struct ASYNC_save_IMU_CONTEXT {
    TASK *task_imu;
    float datas_buff[7];

    bool ready;
    bool save_done;

    ASYNC_save_IMU_STATE state;
    uint32_t max_delay;
    uint32_t imu_delay;
    uint32_t first_time;
    uint32_t next_time;
} ASYNC_save_IMU_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_save_IMU);

void ASYNC_save_IMU_init(TASK *self);
TASK_RETURN ASYNC_save_IMU(SCHEDULER* scheduler, TASK *self);

// ============================================

#define ASYNC_filtred_IMU_NUMBER 5

#define ASYNC_filtred_IMU_DATA_NUMBER 7

typedef enum ASYNC_filtred_IMU_STATE {
    ASYNC_filtred_IMU_START,
    ASYNC_filtred_IMU_START_WAITING_W25Q,
    ASYNC_filtred_IMU_WAIT_OFFSET_BMI_AND_W25Q,
    ASYNC_filtred_IMU_OFFSET_CALCULUS,
    ASYNC_filtred_IMU_WAIT_UPDATE,
    ASYNC_filtred_IMU_END_UPDATE,
} ASYNC_filtred_IMU_STATE;

typedef struct ASYNC_filtred_IMU_CONTEXT {
    TASK *task_imu;
    float datas_buff[7];

    float acc_offset[3][100];
    float gyr_offset[3][100];

    size_t acc_offset_num;
    size_t gyr_offset_num;

    float acc_offset_mean[3];
    float gyr_offset_mean[3];

    BMI088_Data_Pub acc_data;
    BMI088_Data_Pub gyr_data;

    bool w25q_ready;

    ASYNC_filtred_IMU_STATE state;
    uint32_t max_delay;
    uint32_t imu_delay;
    uint32_t first_time;
    uint32_t next_time;
} ASYNC_filtred_IMU_CONTEXT;

extern TASK_POOL_CREATE(ASYNC_filtred_IMU);

void ASYNC_filtred_IMU_init(TASK *self);
TASK_RETURN ASYNC_filtred_IMU(SCHEDULER* scheduler, TASK *self);




#endif // TEST_H