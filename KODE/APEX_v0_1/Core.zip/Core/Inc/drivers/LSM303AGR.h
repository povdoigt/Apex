#ifndef LSM303AGR_H
#define LSM303AGR_H

#include "stm32f4xx_hal.h"


// ============== LSM303AGR REGISTERS ADDRESSES ==============

// Accelerometer device identification
#define LSM303AGR_REG_WHO_AM_I_A 0x0F

// Accelerometer control registers
#define LSM303AGR_REG_CTRL_REG1_A 0x20
#define LSM303AGR_REG_CTRL_REG2_A 0x21
#define LSM303AGR_REG_CTRL_REG3_A 0x22
#define LSM303AGR_REG_CTRL_REG4_A 0x23
#define LSM303AGR_REG_CTRL_REG5_A 0x24
#define LSM303AGR_REG_CTRL_REG6_A 0x25

// Accelerometer output registers
#define LSM303AGR_REG_STATUS_REG_A 0x27

// Accelerometer output registers
#define LSM303AGR_REG_OUT_X_L_A 0x28
#define LSM303AGR_REG_OUT_X_H_A 0x29
#define LSM303AGR_REG_OUT_Y_L_A 0x2A
#define LSM303AGR_REG_OUT_Y_H_A 0x2B
#define LSM303AGR_REG_OUT_Z_L_A 0x2C
#define LSM303AGR_REG_OUT_Z_H_A 0x2D

// FIFO registers
#define LSM303AGR_REG_FIFO_CTRL_REG_A 0x2E
#define LSM303AGR_REG_FIFO_SRC_REG_A 0x2F

// Magnetometer hard-iron registers
#define LSM303AGR_REG_OFFSET_X_L_M 0x05
#define LSM303AGR_REG_OFFSET_X_H_M 0x06
#define LSM303AGR_REG_OFFSET_Y_L_M 0x07
#define LSM303AGR_REG_OFFSET_Y_H_M 0x08
#define LSM303AGR_REG_OFFSET_Z_L_M 0x09
#define LSM303AGR_REG_OFFSET_Z_H_M 0x0A

// Magnetometer device identification
#define LSM303AGR_WHO_AM_I_M 0x4F

// Magnetometer configuration registers
#define LSM303AGR_REG_CFG_REG_A_M 0x60
#define LSM303AGR_REG_CFG_REG_B_M 0x61
#define LSM303AGR_REG_CFG_REG_C_M 0x62

// Magnetometer output registers
#define LSM303AGR_REG_OUTX_L_M 0x68
#define LSM303AGR_REG_OUTX_H_M 0x69
#define LSM303AGR_REG_OUTY_L_M 0x6A
#define LSM303AGR_REG_OUTY_H_M 0x6B
#define LSM303AGR_REG_OUTZ_L_M 0x6C
#define LSM303AGR_REG_OUTZ_H_M 0x6D

// ==============================================================


#define LSM303AGR_SAD_A 0x19 // I2C address for accelerometer
#define LSM303AGR_SAD_M 0x1E // I2C address for magnetometer

#define LSM303AGR_DEVICE_ID_A 0x33 // Device ID for accelerometer
#define LSM303AGR_DEVICE_ID_M 0x40 // Device ID for magnetometer


#define LSM303AGR_


// ========= LSM303AGR Linearly Acceleration Sensiivity ============

#define LSM303AGR_LIN_ACC_SO_2G_HR    0.98 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_4G_HR    1.95 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_8G_HR    3.90 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_16G_HR   7.81 // mg/LSB

#define LSM303AGR_LIN_ACC_SO_2G_N     3.90 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_4G_N     7.82 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_8G_N    15.63 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_16G_N   46.90 // mg/LSB

#define LSM303AGR_LIN_ACC_SO_2G_LP   15.63 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_4G_LP   31.26 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_8G_LP   62.52 // mg/LSB
#define LSM303AGR_LIN_ACC_SO_16G_LP 187.58 // mg/LSB



// =========== LSM303AGR CTRL_REG4_A mask ============

#define LSM303AGR_CTRL_REG4_A_BDU_NON_BLOCKING_MASK 0x80 // Block data update: non-blocking mode
#define LSM303AGR_CTRL_REG4_A_BDU_BLOCKING_MASK     0x00 // Block data update: blocking mode
#define LSM303AGR_CTRL_REG4_A_BLE_LSB_MASK          0x00 // LSB first
#define LSM303AGR_CTRL_REG4_A_BLE_MSB_MASK          0x40 // MSB first
#define LSM303AGR_CTRL_REG4_A_FS_2G_MASK            0x00 // +/-2g
#define LSM303AGR_CTRL_REG4_A_FS_4G_MASK            0x10 // +/-4g
#define LSM303AGR_CTRL_REG4_A_FS_8G_MASK            0x20 // +/-8g
#define LSM303AGR_CTRL_REG4_A_FS_16G_MASK           0x30 // +/-16g
#define LSM303AGR_CTRL_REG4_A_HR_DIS_MASK           0x00 // High resolution: disabled
#define LSM303AGR_CTRL_REG4_A_HR_EN_MASK            0x08 // High resolution: enabled
#define LSM303AGR_CTRL_REG4_A_ST_NORMAL_MASK        0x00 // Self-test: normal mode
#define LSM303AGR_CTRL_REG4_A_ST_0_MASK             0x02 // Self-test: self-test 0
#define LSM303AGR_CTRL_REG4_A_ST_1_MASK             0x04 // Self-test: self-test 1
#define LSM303AGR_CTRL_REG4_A_SPI_DIS_MASK          0x00 // SPI 3-wire interface disabled
#define LSM303AGR_CTRL_REG4_A_SPI_EN_MASK           0x01 // SPI 3-wire interface enabled

typedef struct LSM303AGR {
    I2C_HandleTypeDef *hi2c; // I2C handle

    float acc_data[6]; // Accelerometer data
    float mag_data[6]; // Magnetometer data

    float acc_conv; // Accelerometer conversion factor
    float mag_conv; // Magnetometer conversion factor

} LSM303AGR;


void LSM303AGR_Init(LSM303AGR *lsm, I2C_HandleTypeDef *hi2c);

void LSM303AGR_ReadAcc(LSM303AGR *lsm);


#endif // LSM303AGR_H