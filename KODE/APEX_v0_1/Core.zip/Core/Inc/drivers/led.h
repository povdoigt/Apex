#ifndef LED_H
#define LED_H


#include "stm32f4xx_hal.h"
#include "peripherals/tim.h"

#define LED_TIMER_FREQUENCY 10000 // Frequency for PWM (10 kHz)

typedef struct LED {
    TIM_HandleTypeDef *timer; // Timer handle for PWM
    uint8_t channel; // PWM channel
} LED;

void LED_Init(LED *led, TIM_HandleTypeDef *timer, uint8_t channel);
void LED_SetBrightness(LED *led, uint8_t brightness);

typedef struct LED_RGB {
    LED red;
    LED green;
    LED blue;
} LED_RGB;

void LED_RGB_Init(LED_RGB *led_rgb, TIM_HandleTypeDef *timer,
                  uint8_t red_channel,
                  uint8_t green_channel,
                  uint8_t blue_channel);

void LED_RGB_SetColor(LED_RGB *led_rgb, uint8_t red, uint8_t green, uint8_t blue);

#endif /* LED_H */