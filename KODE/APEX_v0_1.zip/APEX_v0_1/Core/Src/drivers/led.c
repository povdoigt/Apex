#include "drivers/led.h"

void LED_Init(LED *led, TIM_HandleTypeDef *timer, uint8_t channel) {
    led->timer = timer;
    led->channel = channel;

    TIM_set_frequency(timer, LED_TIMER_FREQUENCY); // Set the timer frequency for PWM
    HAL_TIM_PWM_Start(timer, channel);
}

void LED_SetBrightness(LED *led, uint8_t brightness) {
    // from [0 255] to [0 tim->Period]
    uint32_t period = __HAL_TIM_GET_AUTORELOAD(led->timer);
    uint32_t brightness_32 = ((float)brightness / 255.0f) * period;
    __HAL_TIM_SET_COMPARE(led->timer, led->channel, period - brightness_32);
}


void LED_RGB_Init(LED_RGB *led_rgb, TIM_HandleTypeDef *timer,
                   uint8_t red_channel,
                   uint8_t green_channel,
                   uint8_t blue_channel) {
    LED_Init(&led_rgb->red, timer, red_channel);
    LED_Init(&led_rgb->green, timer, green_channel);
    LED_Init(&led_rgb->blue, timer, blue_channel);
    LED_RGB_SetColor(led_rgb, 0, 0, 0); // Initialize RGB LED to off
}

void LED_RGB_SetColor(LED_RGB *led_rgb, uint8_t red, uint8_t green, uint8_t blue) {
    LED_SetBrightness(&led_rgb->red, red);
    LED_SetBrightness(&led_rgb->green, green);
    LED_SetBrightness(&led_rgb->blue, blue);
}
