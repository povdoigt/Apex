#include "drivers/LSM303AGR.h"

void LSM303AGR_Init(LSM303AGR *lsm, I2C_HandleTypeDef *hi2c) {
    lsm->hi2c = hi2c;

    uint8_t data;

    // Accelerometer configuration
    HAL_I2C_Mem_Read(hi2c, LSM303AGR_SAD_A << 1, LSM303AGR_REG_WHO_AM_I_A, I2C_MEMADD_SIZE_8BIT, &data, 1, HAL_MAX_DELAY);
    if (data != LSM303AGR_DEVICE_ID_A) {
        // Handle error: Device ID mismatch
        return;
    }

    data = 0x57; // 0b01010111 // 100Hz, normal mode, all axes enabled
    HAL_I2C_Mem_Write(hi2c, LSM303AGR_SAD_A << 1, LSM303AGR_REG_CTRL_REG1_A, I2C_MEMADD_SIZE_8BIT, data, 1, HAL_MAX_DELAY);

    data = 0x00;
    data |= LSM303AGR_CTRL_REG4_A_BDU_BLOCKING_MASK; // Block data update: blocking mode
    data |= LSM303AGR_CTRL_REG4_A_BLE_LSB_MASK; // LSB first
    data |= LSM303AGR_CTRL_REG4_A_FS_2G_MASK; // +/-2g
    data |= LSM303AGR_CTRL_REG4_A_HR_EN_MASK; // High resolution: enabled
    data |= LSM303AGR_CTRL_REG4_A_ST_NORMAL_MASK; // Self-test: normal mode
    data |= LSM303AGR_CTRL_REG4_A_SPI_DIS_MASK; // SPI 3-wire interface disabled
    HAL_I2C_Mem_Write(hi2c, LSM303AGR_SAD_A << 1, LSM303AGR_REG_CTRL_REG4_A, I2C_MEMADD_SIZE_8BIT, &data, 1, HAL_MAX_DELAY);
    lsm->acc_conv = LSM303AGR_LIN_ACC_SO_2G_HR; // Set conversion factor for +/-2g range


    // Magnetometer configuration
    HAL_I2C_Mem_Read(hi2c, LSM303AGR_SAD_M << 1, LSM303AGR_WHO_AM_I_M, I2C_MEMADD_SIZE_8BIT, &data, 1, HAL_MAX_DELAY);
    if (data != LSM303AGR_DEVICE_ID_M) {
        // Handle error: Device ID mismatch
        return;
    }

    data = 0x8C; // 0b10001100 // Temperature compensation enabled, 100Hz, normal mode
    HAL_I2C_Mem_Write(hi2c, LSM303AGR_SAD_M << 1, LSM303AGR_REG_CFG_REG_A_M, I2C_MEMADD_SIZE_8BIT, &data, 1, HAL_MAX_DELAY);
}




void LSM303AGR_ReadAcc(LSM303AGR *lsm) {
    uint8_t data[6];
    // HAL_I2C_Mem_Read(lsm->hi2c, LSM303AGR_SAD_A << 1, LSM303AGR_REG_OUT_X_L_A | 0x80, I2C_MEMADD_SIZE_8BIT, data, 6, HAL_MAX_DELAY);
    HAL_I2C_Mem_Read(lsm->hi2c, LSM303AGR_SAD_A << 1, LSM303AGR_REG_OUT_X_L_A, I2C_MEMADD_SIZE_8BIT, data, 1, HAL_MAX_DELAY);
    
    lsm->acc_data[0] = (int16_t)((data[1] << 8) | data[0]) * lsm->acc_conv; // X-axis
    lsm->acc_data[1] = (int16_t)((data[3] << 8) | data[2]) * lsm->acc_conv; // Y-axis
    lsm->acc_data[2] = (int16_t)((data[5] << 8) | data[4]) * lsm->acc_conv; // Z-axis
}