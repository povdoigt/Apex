#ifndef SX127x_LORA_H
#define SX127x_LORA_H

#include "drivers/sx127x/sx127x_common.h"
#include "stm32f4xx_hal.h"
#include "peripherals/spi.h"
#include "utils/scheduler.h"
#include <stdbool.h>


// Register names (LoRa Mode)
// REG 00~01 are common
// REG 02~05 are mode specific
// REG 06~09 are common
// REG 0A are mode specific
// REG 0B~0C are common
#define sx127x_LORA_REG_0D_FIFO_ADDR_PTR			0x0d
#define sx127x_LORA_REG_0E_FIFO_TX_BASE_ADDR		0x0e
#define sx127x_LORA_REG_0F_FIFO_RX_BASE_ADDR		0x0f
#define sx127x_LORA_REG_10_FIFO_RX_CURRENT_ADDR		0x10
#define sx127x_LORA_REG_11_IRQ_FLAGS_MSK			0x11
#define sx127x_LORA_REG_12_IRQ_FLAGS				0x12
#define sx127x_LORA_REG_13_RX_NB_BYTES				0x13
#define sx127x_LORA_REG_14_RX_HEADER_CNT_VALUE_MSB	0x14
#define sx127x_LORA_REG_15_RX_HEADER_CNT_VALUE_LSB	0x15
#define sx127x_LORA_REG_16_RX_PACKET_CNT_VALUE_MSB	0x16
#define sx127x_LORA_REG_17_RX_PACKET_CNT_VALUE_LSB	0x17
#define sx127x_LORA_REG_18_MODEM_STAT				0x18
#define sx127x_LORA_REG_19_PKT_SNR_VALUE			0x19
#define sx127x_LORA_REG_1A_PKT_RSSI_VALUE			0x1a
#define sx127x_LORA_REG_1B_RSSI_VALUE				0x1b
#define sx127x_LORA_REG_1C_HOP_CHANNEL				0x1c
#define sx127x_LORA_REG_1D_MODEM_CONFIG1			0x1d
#define sx127x_LORA_REG_1E_MODEM_CONFIG2			0x1e
#define sx127x_LORA_REG_1F_SYMB_TIMEOUT_LSB			0x1f
#define sx127x_LORA_REG_20_PREAMBLE_MSB				0x20
#define sx127x_LORA_REG_21_PREAMBLE_LSB				0x21
#define sx127x_LORA_REG_22_PAYLOAD_LENGTH			0x22
#define sx127x_LORA_REG_23_MAX_PAYLOAD_LENGTH		0x23
#define sx127x_LORA_REG_24_HOP_PERIOD				0x24
#define sx127x_LORA_REG_25_FIFO_RX_BYTE_ADDR		0x25
#define sx127x_LORA_REG_26_MODEM_CONFIG3			0x26
#define sx127x_LORA_REG_27_PPM_CORRECTION			0x27
#define sx127x_LORA_REG_28_FEI_MSB					0x28
#define sx127x_LORA_REG_29_FEI_MID					0x29
#define sx127x_LORA_REG_2A_FEI_LSB					0x2a
// REG 2B is reserved
#define sx127x_LORA_REG_2C_RSSI_WIDEBAND			0x2c
// REG 2D~2E are reserved
#define sx127x_LORA_REG_2F_IF_FREQ2					0x2f
#define sx127x_LORA_REG_30_IF_FREQ1					0x30
#define sx127x_LORA_REG_31_DETECT_OPTIMIZ			0x31
// REG 32 is reserved
#define sx127x_LORA_REG_33_INVERT_IQ				0x33
// REG 34~35 are reserved
#define sx127x_LORA_REG_37_DETECTION_THRESHOLD		0x37
// REG 38 is reserved
#define sx127x_LORA_REG_39_SYNC_WORD				0x39
#define sx127x_LORA_REG_3A_HIGH_BW_OPTIMIZ2			0x3a
#define sx127x_LORA_REG_3B_INVERT_IQ2				0x3b






// ====================== 0x01 RegOpMode ======================
// [7] LongRangeMode:
typedef enum sx127x_LORA_REG_01_OP_MODE_LRM {
	sx127x_LORA_REG_01_OP_MODE_LRM_FSK_OOK	= 0b00000000,	// FSK/OOK mode
	sx127x_LORA_REG_01_OP_MODE_LRM_LoRa   	= 0b10000000,	// LoRa mode
} sx127x_LORA_REG_01_OP_MODE_LRM;
#define sx127x_LORA_REG_01_OP_MODE_LRM_MSK 0b10000000
// [6] AccessSharedReg:
typedef enum sx127x_LORA_REG_01_OP_MODE_ASR {
	sx127x_LORA_REG_01_OP_MODE_ASR_LoRa   	= 0b00000000,	// Access LoRa registers
	sx127x_LORA_REG_01_OP_MODE_ASR_FSK_OOK	= 0b01000000,	// Access FSK/OOK registers
} sx127x_LORA_REG_01_OP_MODE_ASR;
#define sx127x_LORA_REG_01_OP_MODE_ASR_MSK 0b01000000
// [5-4] Reserved
// [3] LowFrequencyModeOn:
typedef enum sx127x_LORA_REG_01_OP_MODE_LFMO {
	sx127x_LORA_REG_01_OP_MODE_LFMO_OFF	= 0b00000000,	// HF mode (> 525MHz)
	sx127x_LORA_REG_01_OP_MODE_LFMO_ON 	= 0b00001000,	// LF mode (<= 525MHz)
} sx127x_LORA_REG_01_OP_MODE_LFMO;
#define sx127x_LORA_REG_01_OP_MODE_LFMO_MSK 0b00001000
// [2-0] Mode:
typedef enum sx127x_LORA_REG_01_OP_MODE_MODE {
	sx127x_LORA_REG_01_OP_MODE_MODE_SLEEP        	= 0b00000000,	// Sleep
	sx127x_LORA_REG_01_OP_MODE_MODE_STDBY        	= 0b00000001,	// Standby
	sx127x_LORA_REG_01_OP_MODE_MODE_FSTX         	= 0b00000010,	// FSTX
	sx127x_LORA_REG_01_OP_MODE_MODE_TX           	= 0b00000011,	// Tx
	sx127x_LORA_REG_01_OP_MODE_MODE_FSRX         	= 0b00000100,	// FSRX
	sx127x_LORA_REG_01_OP_MODE_MODE_RX_CONTINUOUS	= 0b00000101,	// RxContinuous
	sx127x_LORA_REG_01_OP_MODE_MODE_RX_SINGLE    	= 0b00000110,	// RxSingle
	sx127x_LORA_REG_01_OP_MODE_MODE_CAD          	= 0b00000111,	// CAD
} sx127x_LORA_REG_01_OP_MODE_MODE;
#define sx127x_LORA_REG_01_OP_MODE_MODE_MSK 0b00000111





// ====================== 0x11 & 0x12 RegIrqFlags & RegIrqFlagsMSK ======================
#define sx127x_LORA_IRQ_FLAG_RX_TIMEOUT_MSK         	0b10000000
#define sx127x_LORA_IRQ_FLAG_RX_DONE_MSK            	0b01000000
#define sx127x_LORA_IRQ_FLAG_PAYLOAD_CRC_ERROR_MSK  	0b00100000
#define sx127x_LORA_IRQ_FLAG_VALID_HEADER_MSK       	0b00010000
#define sx127x_LORA_IRQ_FLAG_TX_DONE_MSK            	0b00001000
#define sx127x_LORA_IRQ_FLAG_CAD_DONE_MSK           	0b00000100
#define sx127x_LORA_IRQ_FLAG_FHSS_CHANGE_CHANNEL_MSK	0b00000010
#define sx127x_LORA_IRQ_FLAG_CAD_DETECTED_MSK       	0b00000001





// ====================== 0x18 RegModemStat ======================
#define sx127x_LORA_RX_CODING_RATE_MSK					0b11100000
#define sx127x_LORA_MODEM_STATUS_CLEAR_MSK				0b00010000
#define sx127x_LORA_MODEM_STATUS_HEADER_VALID_MSK		0b00001000
#define sx127x_LORA_MODEM_STATUS_RX_ONGOING_MSK			0b00000100
#define sx127x_LORA_MODEM_STATUS_SIGNAL_SYNC_MSK		0b00000010
#define sx127x_LORA_MODEM_STATUS_SIGNAL_DETECTED_MSK	0b00000001





// ====================== 0x1c RegHopChannel ======================
#define sx127x_LORA_PLL_TIMEOUT_MSK				0b10000000
#define sx127x_LORA_RX_PAYLOAD_CRC_IS_ON_MSK	0b01000000
#define sx127x_LORA_FHSS_PRESENT_CHANNEL_MSK	0b00111111





// ====================== 0x1d RedModemConfig1 ======================
// [7-4] Bandwidth:
typedef enum sx127x_LORA_REG_1D_MODEM_CONFIG1_BW {
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_7_8KHZ		= 0b00000000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_10_4KHZ		= 0b00010000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_15_6KHZ		= 0b00100000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_20_8KHZ		= 0b00110000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_31_25KHZ	= 0b01000000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_41_7KHZ		= 0b01010000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_62_5KHZ		= 0b01100000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_125KHZ		= 0b01110000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_250KHZ		= 0b10000000,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_500KHZ		= 0b10010000,
	// 1010 to 1111 reserved
} sx127x_LORA_REG_1D_MODEM_CONFIG1_BW;
#define sx127x_LORA_REG_1D_MODEM_CONFIG1_BW_MSK 0b11110000
// [3-1] CodingRate:
typedef enum sx127x_LORA_REG_1D_MODEM_CONFIG1_CR {
	sx127x_LORA_REG_1D_MODEM_CONFIG1_CR_4_5	= 0b00000010,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_CR_4_6	= 0b00000100,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_CR_4_7	= 0b00000110,
	sx127x_LORA_REG_1D_MODEM_CONFIG1_CR_4_8	= 0b00001000,
	// 101 to 111 reserved
} sx127x_LORA_REG_1D_MODEM_CONFIG1_CR;
#define sx127x_LORA_REG_1D_MODEM_CONFIG1_CR_MSK 0b00001110
// [0] ImplicitHeaderModeOn:
typedef enum sx127x_LORA_REG_1D_MODEM_CONFIG1_IHMO {
	sx127x_LORA_REG_1D_MODEM_CONFIG1_IHMO_OFF	= 0b00000000,	// Explicit header mode
	sx127x_LORA_REG_1D_MODEM_CONFIG1_IHMO_ON	= 0b00000001,	// Implicit header mode
} sx127x_LORA_REG_1D_MODEM_CONFIG1_IHMO;
#define sx127x_LORA_REG_1D_MODEM_CONFIG1_IHMO_MSK 0b00000001





// ====================== 0x1e RegModemConfig2 ======================
// [7-4] SpreadingFactor:
typedef enum sx127x_LORA_REG_1E_MODEM_CONFIG2_SF {
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_64CPS	= 0b01100000,	// SF6
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_128CPS	= 0b01110000,	// SF7
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_256CPS	= 0b10000000,	// SF8
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_512CPS	= 0b10010000,	// SF9
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_1024CPS	= 0b10100000,	// SF10
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_2048CPS	= 0b10110000,	// SF11
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_4096CPS	= 0b11000000,	// SF12
	// 1101 to 1111 reserved
} sx127x_LORA_REG_1E_MODEM_CONFIG2_SF;
#define sx127x_LORA_REG_1E_MODEM_CONFIG2_SF_MSK		0b11110000
// [3] TxContinuousMode:
typedef enum sx127x_LORA_REG_1E_MODEM_CONFIG2_TXCM {
	sx127x_LORA_REG_1E_MODEM_CONFIG2_TXCM_OFF	= 0b00000000,	// Normal Tx mode
	sx127x_LORA_REG_1E_MODEM_CONFIG2_TXCM_ON	= 0b00001000,	// Continuous Tx mode
} sx127x_LORA_REG_1E_MODEM_CONFIG2_TXCM;
#define sx127x_LORA_REG_1E_MODEM_CONFIG2_TXCM_MSK	0b00001000
// [2] RxPayloadCrcOn:
typedef enum sx127x_LORA_REG_1E_MODEM_CONFIG2_RPC {
	sx127x_LORA_REG_1E_MODEM_CONFIG2_RPC_OFF	= 0b00000000,	// CRC disabled
	sx127x_LORA_REG_1E_MODEM_CONFIG2_RPC_ON		= 0b00000100,	// CRC enabled
} sx127x_LORA_REG_1E_MODEM_CONFIG2_RPC;
#define sx127x_LORA_REG_1E_MODEM_CONFIG2_RPC_MSK	0b00000100
// [1-0] SymbTimeoutMSB:
#define sx127x_LORA_REG_1E_MODEM_CONFIG2_SYMB_TIMEOUT_MSB_MSK	0b00000011





// ====================== 0x26 RegModemConfig3 ======================
// [7-4] Unused
// [3] LowDataRateOptimize:
typedef enum sx127x_LORA_REG_26_MODEM_CONFIG3_LDRO {
	sx127x_LORA_REG_26_MODEM_CONFIG3_LDRO_OFF	= 0b00000000,	// Disabled
	sx127x_LORA_REG_26_MODEM_CONFIG3_LDRO_ON	= 0b00001000,	// Enabled
} sx127x_LORA_REG_26_MODEM_CONFIG3_LDRO;
#define sx127x_LORA_REG_26_MODEM_CONFIG3_LDRO_MSK 0b00001000
// [2] AgcAutoOn:
typedef enum sx127x_LORA_REG_26_MODEM_CONFIG3_AGCAO {
	sx127x_LORA_REG_26_MODEM_CONFIG3_AGCAO_OFF	= 0b00000000,	// LNA gain set by RegLna
	sx127x_LORA_REG_26_MODEM_CONFIG3_AGCAO_ON	= 0b00000100,	// LNA gain set by AGC loop
} sx127x_LORA_REG_26_MODEM_CONFIG3_AGCAO;
// [1-0] Reserved





// ====================== 0x40 RegDioMapping1 ======================
// (masks are common with FSK/OOK mode)
// [7-6] DIO0 Mapping:
typedef enum sx127x_LORA_REG_40_DIO_MAPPING1_DIO0 {
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO0_RX_DONE	= 0b00000000,	// RxDone
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO0_TX_DONE	= 0b01000000,	// TxDone
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO0_CAD_DONE	= 0b10000000,	// CadDone
	// 11 reserved
} sx127x_LORA_REG_40_DIO_MAPPING1_DIO0;
// [5-4] DIO1 Mapping:
typedef enum sx127x_LORA_REG_40_DIO_MAPPING1_DIO1 {
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO1_RX_TIMEOUT				= 0b00000000,	// RxTimeout
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO1_FHSS_CHANGE_CHANNEL	= 0b00100000,	// FhssChangeChannel
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO1_CAD_DETECTED			= 0b01000000,	// CadDetected
	// 11 reserved
} sx127x_LORA_REG_40_DIO_MAPPING1_DIO1;
// [3-2] DIO2 Mapping:
typedef enum sx127x_LORA_REG_40_DIO_MAPPING1_DIO2 {
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO2_FHSS_PRESENT_CHANNEL	= 0b00000000,	// FhssPresentChannel
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO2_FHSS_PRESENT_CHANNEL1	= 0b00000100,	// FhssPresentChannel (same as 00)
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO2_FHSS_PRESENT_CHANNEL2	= 0b00001000,	// FhssPresentChannel (same as 00)
	// 11 reserved
} sx127x_LORA_REG_40_DIO_MAPPING1_DIO2;
// [1-0] DIO3 Mapping:
typedef enum sx127x_LORA_REG_40_DIO_MAPPING1_DIO3 {
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO3_CAD_DONE			= 0b00000000,	// CadDone
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO3_VAILD_HEADER		= 0b00000001,	// ValidHeader
	sx127x_LORA_REG_40_DIO_MAPPING1_DIO3_PAYLOAD_CRC_ERROR	= 0b00000010,	// PayloadCrcError
	// 11 reserved
} sx127x_LORA_REG_40_DIO_MAPPING1_DIO3;





// ====================== 0x41 RegDioMapping2 ======================
// (masks are common with FSK/OOK mode)
// [7-6] DIO4 Mapping:
typedef enum sx127x_LORA_REG_41_DIO_MAPPING2_DIO4 {
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO4_CAD_DETECTED	= 0b00000000,	// CadDetected
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO4_PLL_LOCK		= 0b01000000,	// PllLock
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO4_PLL_LOCK1		= 0b10000000,	// PllLock (same as 01)
	// 11 reserved
} sx127x_LORA_REG_41_DIO_MAPPING2_DIO4;
// [5-4] DIO5 Mapping:
typedef enum sx127x_LORA_REG_41_DIO_MAPPING2_DIO5 {
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO5_MODE_READY	= 0b00000000,	// ModeReady
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO5_CLK_OUT	= 0b01000000,	// ClkOut
	sx127x_LORA_REG_41_DIO_MAPPING2_DIO5_CLK_OUT1	= 0b10000000,	// ClkOut (same as 01)
	// 11 reserved
} sx127x_LORA_REG_41_DIO_MAPPING2_DIO5;
// [3-1] Reserved
// [0] ClkOutOnPayloadReady (common with FSK/OOK mode)








typedef struct sx127x_LORA_config_t {
	bool									implicitHeader;
	sx127x_LORA_REG_1D_MODEM_CONFIG1_BW		bandwidth;
	sx127x_LORA_REG_1D_MODEM_CONFIG1_CR		codingRate;
	sx127x_LORA_REG_1E_MODEM_CONFIG2_SF		spreadingFactor;
	bool 									crcEnabled;
} sx127x_LORA_config_t;

typedef struct sx127x_LORA_chip_t {
	sx127x_base_chip_t *base_chip;
	sx127x_LORA_config_t config;
} sx127x_LORA_chip_t;



sx127x_status_t	sx127x_LORA_Config(sx127x_LORA_chip_t *chip, sx127x_base_chip_t *base_chip, sx127x_LORA_config_t config);

sx127x_status_t sx127x_LORA_TxSend(sx127x_LORA_chip_t *chip, const uint8_t *data, uint8_t len);
sx127x_status_t sx127x_LORA_RxReceive(sx127x_LORA_chip_t *chip, uint8_t *data, uint8_t *len);




/* ============================== FreeRTOS ============================== */

sx127x_status_t	sx127x_LORA_Config_RTOS(sx127x_LORA_chip_t *chip, sx127x_base_chip_t *base_chip, sx127x_LORA_config_t config);

sx127x_status_t sx127x_LORA_TxSend_RTOS(sx127x_LORA_chip_t *chip, const uint8_t *data, uint8_t len);
sx127x_status_t sx127x_LORA_RxReceive_RTOS(sx127x_LORA_chip_t *chip, uint8_t *data, uint8_t *len);

#endif // SX127X_LORA_H