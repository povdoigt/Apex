
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "utils/scheduler.h"
#include "cmsis_os2.h"


#include "FreeRTOS.h"
#include "portable.h"
#include "task.h"


// ================== SCHEUDLER ==================

const char prefix[11] = "TASK_ARGS_";

void TASK_ARGUMENTS_init(TASK_ARGUMENTS *task_args, void *args, const osThreadAttr_t *attr) {
    task_args->attr = attr;
    strcpy(task_args->name, prefix);

    if (task_args->attr) {
       if (task_args->attr->name) {
            strncat(task_args->name, task_args->attr->name,
                TASK_ARG_MAX_NAME_LEN - strlen(task_args->name) - 1);
        }
    } else {
        strncat(task_args->name, "defalut",
            TASK_ARG_MAX_NAME_LEN - strlen(task_args->name) - 1);
    }

    task_args->attr_semaphore = (osSemaphoreAttr_t){
        .name = task_args->name,
    };
    // To be sure that all the fields are initialized to zero
    // exept the name 

    task_args->arg_semaphore = osSemaphoreNew(1, 0, &(task_args->attr_semaphore));
    // task_args->arg_semaphore = osSemaphoreNew(1, 0, NULL);
    task_args->agrs = args;
}

void TASK_ARGUMENTS_ok(TASK_ARGUMENTS *task_args) {
    osSemaphoreRelease(task_args->arg_semaphore);
}

void TASK_ARGUMENTS_wait(TASK_ARGUMENTS *task_args, uint32_t timeout) {
    osSemaphoreAcquire(task_args->arg_semaphore, timeout);
    osSemaphoreDelete(task_args->arg_semaphore);
}

void osThreadNew_args(osThreadFunc_arg_t func, TASK_ARGUMENTS *task_args) {
    osThreadNew((osThreadFunc_t)func, (void *)task_args, task_args->attr);
}
