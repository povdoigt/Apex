#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdbool.h>

#include "cmsis_os2.h"
#include "stm32f4xx_hal.h"

#include "utils/obj_pool.h"
#include "utils/circular_buffer.h"


#define TASK_ARG_MAX_NAME_LEN 64



typedef struct TASK_ARGUMENTS {
    osSemaphoreId_t          arg_semaphore;
    osSemaphoreAttr_t        attr_semaphore;
    const osThreadAttr_t    *attr;
    void                    *agrs;
    char                     name[TASK_ARG_MAX_NAME_LEN];
} TASK_ARGUMENTS;

typedef void (*osThreadFunc_arg_t)(TASK_ARGUMENTS *argument);

void TASK_ARGUMENTS_init(TASK_ARGUMENTS *task_args, void *args, const osThreadAttr_t *attr);

void TASK_ARGUMENTS_ok(TASK_ARGUMENTS *task_args);

void TASK_ARGUMENTS_wait(TASK_ARGUMENTS *task_args, uint32_t timeout);

void osThreadNew_args(osThreadFunc_arg_t func, TASK_ARGUMENTS *task_args);

#endif // SCHEDULER_H